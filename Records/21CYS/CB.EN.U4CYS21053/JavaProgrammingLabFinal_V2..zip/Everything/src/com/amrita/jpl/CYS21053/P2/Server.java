package com.amrita.jpl.CYS21053.P2;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Author: Nived Dineshan
 * Version: 0.5
 */
abstract class QuizGame {

    /**
     * Starts the Game
     */
    void startGame(){

    }

    /**
     * Asks Question to com.amrita.jpl.cys21053.p2.Client
     */

    abstract void askQuestion();

    /**
     * Function is used to receive and evaluate the answer sent by the client
     * @param ans -> the answer sent by the client
     *
     */
    abstract void evaluateAnswer(String ans);

}

interface QuizGameListener{
    /**
     * @param question-> contains the question asked
     */
    void onQuestionAsked(String question);

    /**
     * @param isCorrect-> 0 for wrong and 1 for correct
     * used to check if the answer is correct and has to be added to the score
     */
    void onAnswerEvaluated(boolean isCorrect);
}

class QuizGameServer extends QuizGame{
    /**
     * Starts the Game
     */
    void startGame(){
        System.out.println("Game Started");


    }
    /**
     * Asks Question to com.amrita.jpl.cys21053.p2.Client
     */

    void askQuestion(){

    }
    /**
     * Function is used to receive and evaluate the answer sent by the client
     * @param ans -> the answer sent by the client
     *
     */
    void evaluateAnswer(String ans){

    }
}
public class Server {


    public static void main(String[] args) {
        String Questions[] = new String[5];
        String Answers[] = new String[5];
        Questions[0] = "What is the capital of India?";
        Questions[1] = "Football player with the most balon dors?";
        Questions[2] = "Year India obtained Independence? ";
        Questions[3] = "Football club with the most Champions League Titles?";
        Questions[4] = "Is New York the capital of USA ? (True or False)";

        Answers[0] = "New Delhi";
        Answers[1] = "Messi";
        Answers[2] = "1947";
        Answers[3] = "Real Madrid";
        Answers[4] = "False";



        try {
            ServerSocket serverSocket = new ServerSocket(2444);
            Socket clientSocket = serverSocket.accept();
            InetAddress clientAddress = clientSocket.getInetAddress();
            int clientPort = clientSocket.getPort();
            DataInputStream dataInputStream = new DataInputStream(clientSocket.getInputStream());

            String message = "";
            int i=0;
            int score=0;
            while (!message.equalsIgnoreCase("exit") && i<5) {
                String question = Questions[i];
                DataOutputStream dataOutputStream = new DataOutputStream(clientSocket.getOutputStream());
                dataOutputStream.writeUTF(question);
                message = dataInputStream.readUTF();
                System.out.println(" Message from client: " + message);
                if(message.equals(Answers[i]) ){
                    score=score+1;
                }
                i=i+1;
            }

            System.out.println("Score is "+ score +" out of 5");
            serverSocket.close();
            System.out.println("Server closed.");
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }

    }
}